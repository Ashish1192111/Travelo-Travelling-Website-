<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Travelo</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
    <!-- swiper css -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@8/swiper-bundle.min.css" />

    <!-- css file  -->
    <link rel="stylesheet" href="css/style.css">

    <!-- font awesome CDN link -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
</head>

<body>

    <!-- navbar -->
    <?php include 'include/nav.php'; ?>


    <!-- About page -->
    <div class="heading-about">
        <h3>about us</h3>
    </div>

    <section class="about">
        <div class="img">
            <p class="imglogo"><i class="fa-sharp fa-solid fa-plane"></i>Travelo</p>
        </div>

        <div class="aboutus">
            <h3>Who we are</h3>
            <p>We are a leading online travel company in India providing a 'best in class' customer experience with the
                goal to be 'India's Travel Planner'. Through our website, www.yatra.com, our mobile applications and our
                other associated platforms, leisure and business travelers can explore, research, compare prices and
                book a wide range of services catering to their travel needs. Since our inception in 2006, more than 7
                million customers have used one or more of our comprehensive travel-related services, which include
                domestic and international air ticketing, hotel bookings, homestays, holiday packages, bus ticketing,
                rail ticketing, activities and ancillary services. With over 103,000 hotels contracted across India, we
                are India's largest platform for domestic hotels.</p>

            <div class="icon-container">
                <div class="icons">
                    <i class="fas fa-map"></i>
                    <span>Top Destinations</span>
                </div>
                <div class="icons">
                    <i class="fas fa-hand-holding-heart"></i>
                    <span>Love</span>
                </div>
                <div class="icons">
                    <i class="fas fa-hand-holding-usd"></i>
                    <span>Low price</span>
                </div>
                <div class="icons">
                    <i class="fas fa-headset"></i>
                    <span>24x7 services</span>
                </div>
            </div>
        </div>
    </section>


    <!-- Review -->
    <section class="review">
        <h1 class="heading-title">Reviews</h1>
        <div class="swiper review-slider">
            <div class="swiper-wrapper">
                <div class="swiper-slide slide">
                    <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Eaque facere rem magnam porro ab dolore
                        atque, quibusdam recusandae aperiam unde. Maiores nihil sequi nam molestiae reprehenderit
                        expedita sit quibusdam provident?</p>
                    <div class="stars">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <h3>Ashish Sharma</h3>
                        <span>Programmer</span>
                        <img src="img/review1.jpeg" alt="review">
                    </div>
                </div>
                <div class="swiper-slide slide">
                    <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Eaque facere rem magnam porro ab dolore
                        atque, quibusdam recusandae aperiam unde. Maiores nihil sequi nam molestiae reprehenderit
                        expedita sit quibusdam provident?</p>
                    <div class="stars">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half"></i>
                        <h3>Ashish Sharma</h3>
                        <span>Programmer</span>
                        <img src="img/review1.jpeg" alt="review">
                    </div>
                </div>
                <div class="swiper-slide slide">
                    <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Eaque facere rem magnam porro ab dolore
                        atque, quibusdam recusandae aperiam unde. Maiores nihil sequi nam molestiae reprehenderit
                        expedita sit quibusdam provident?</p>
                    <div class="stars">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half"></i>

                        <h3>Ashish Sharma</h3>
                        <span>Programmer</span>
                        <img src="img/review1.jpeg" alt="review">
                    </div>
                </div>
                <div class="swiper-slide slide">
                    <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Eaque facere rem magnam porro ab dolore
                        atque, quibusdam recusandae aperiam unde. Maiores nihil sequi nam molestiae reprehenderit
                        expedita sit quibusdam provident?</p>
                    <div class="stars">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <h3>Ashish Sharma</h3>
                        <span>Programmer</span>
                        <img src="img/review1.jpeg" alt="review">
                    </div>
                </div>
                <div class="swiper-slide slide">
                    <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Eaque facere rem magnam porro ab dolore
                        atque, quibusdam recusandae aperiam unde. Maiores nihil sequi nam molestiae reprehenderit
                        expedita sit quibusdam provident?</p>
                    <div class="stars">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half"></i>
                        <h3>Ashish Sharma</h3>
                        <span>Programmer</span>
                        <img src="img/review1.jpeg" alt="review">
                    </div>
                </div>
                <div class="swiper-slide slide">
                    <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Eaque facere rem magnam porro ab dolore
                        atque, quibusdam recusandae aperiam unde. Maiores nihil sequi nam molestiae reprehenderit
                        expedita sit quibusdam provident?</p>
                    <div class="stars">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half"></i>
                        <h3>Ashish Sharma</h3>
                        <span>Programmer</span>
                        <img src="img/review1.jpeg" alt="review">
                    </div>
                </div>
                <div class="swiper-slide slide">
                    <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Eaque facere rem magnam porro ab dolore
                        atque, quibusdam recusandae aperiam unde. Maiores nihil sequi nam molestiae reprehenderit
                        expedita sit quibusdam provident?</p>
                    <div class="stars">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half"></i>
                        <h3>Ashish Sharma</h3>
                        <span>Programmer</span>
                        <img src="img/review1.jpeg" alt="review">
                    </div>
                </div>
                <div class="swiper-slide slide">
                    <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Eaque facere rem magnam porro ab dolore
                        atque, quibusdam recusandae aperiam unde. Maiores nihil sequi nam molestiae reprehenderit
                        expedita sit quibusdam provident?</p>
                    <div class="stars">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half"></i>
                        <h3>Ashish Sharma</h3>
                        <span>Programmer</span>
                        <img src="img/review1.jpeg" alt="review">
                    </div>
                </div>
            </div>
        </div>
    </section>





    <!-- Footer -->
    <?php include 'include/footer.php'; ?>




    <!-- swiper js link -->
    <script src="https://cdn.jsdelivr.net/npm/swiper@8/swiper-bundle.min.js"></script>

    <!-- javascript file -->
    <script src='script.js'></script>



</body>

</html>