<?php

   $connection = mysqli_connect('localhost','root','','travelo');

   if(isset($_POST['send'])){
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $email = $_POST['email'];
    $number = $_POST['number'];
    $address = $_POST['address'];
    $trip = $_POST['trip'];
    $person = $_POST['person'];
    $arrival = $_POST['arrival'];
    $departure = $_POST['departure'];

      $request = "insert into form (fname, lname, email, number, address, trip, person, arrival, departure) values('$fname','$lname','$email','$number','$address','$trip','$person','$arrival','$departure')";
      mysqli_query($connection, $request);

      header('location:thank.php'); 

   }else{
      echo 'something went wrong please try again!';
   }
