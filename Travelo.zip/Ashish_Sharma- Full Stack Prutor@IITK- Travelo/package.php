<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Travelo</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">

    <!-- css file  -->
    <link rel="stylesheet" href="css/style.css">
    <!-- swiper css -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@8/swiper-bundle.min.css" />

    <!-- font awesome CDN link -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
</head>

<body>

    <!-- navbar -->
    <?php include 'include/nav.php'; ?>
    <!-- package page -->
    <div class="heading-package">
        <h3>Packages</h3>
    </div>

    <section class="packages home-packages">

        <div class="box-container">
            <div class="box">
                <div class="image">
                    <img src="img/pack.jpg" alt="">
                </div>
                <div class="content">
                    <h3>Andaman & Nicobar </h3>
                    <p>12000.00 ₹/person </p>
                    <a href="book.php" class="btn">Book Now</a>
                </div>
            </div>
            <div class="box">
                <div class="image">
                    <img src="img/pack2.jpg" alt="">
                </div>
                <div class="content">
                    <h3>Manali, H.P</h3>
                    <p> 6000.00 ₹/person</p>
                    <a href="book.php" class="btn">Book Now</a>
                </div>
            </div>
            <div class="box">
                <div class="image">
                    <img src="img/pack3.jpg" alt="">
                </div>
                <div class="content">
                    <h3>Alleppey, kerala</h3>
                    <p>7500.00 ₹/person</p>
                    <a href="book.php" class="btn">Book Now</a>
                </div>
            </div>
            <div class="box">
                <div class="image">
                    <img src="img/pack4.jpg" alt="">
                </div>
                <div class="content">
                    <h3>Leh Ladakh</h3>
                    <p>13500.00 ₹/person</p>
                    <a href="book.php" class="btn">Book Now</a>
                </div>
            </div>
            <div class="box">
                <div class="image">
                    <img src="img/pack5.jpg" alt="">
                </div>
                <div class="content">
                    <h3>Goa</h3>
                    <p>10000.00 ₹/person</p>
                    <a href="book.php" class="btn">Book Now</a>
                </div>
            </div>
            <div class="box">
                <div class="image">
                    <img src="img/pack6.jpg" alt="">
                </div>
                <div class="content">
                    <h3>Coorg, Karnataka</h3>
                    <p>10000.00 ₹/person</p>
                    <a href="book.php" class="btn">Book Now</a>
                </div>
            </div>
            <div class="box">
                <div class="image">
                    <img src="img/pack7.jpg" alt="">
                </div>
                <div class="content">
                    <h3>Gangtok, Sikkim</h3>
                    <p>7850.00 ₹/person</p>
                    <a href="book.php" class="btn">Book Now</a>
                </div>
            </div>
            <div class="box">
                <div class="image">
                    <img src="img/pack8.jpg" alt="">
                </div>
                <div class="content">
                    <h3>Shimla, H.P</h3>
                    <p>6000.00 ₹/person</p>
                    <a href="book.php" class="btn">Book Now</a>
                </div>
            </div>
            <div class="box">
                <div class="image">
                    <img src="img/pack9.jpg" alt="">
                </div>
                <div class="content">
                    <h3>Ooty, Tamil Nadu </h3>
                    <p>10000.00 ₹/person</p>
                    <a href="book.php" class="btn">Book Now</a>
                </div>
            </div>
            <div class="box">
                <div class="image">
                    <img src="img/pack10.jpg" alt="">
                </div>
                <div class="content">
                    <h3>Udaipur, Rajasthan</h3>
                    <p>11500.00 ₹/person</p>
                    <a href="book.php" class="btn">Book Now</a>
                </div>
            </div>
            <div class="box">
                <div class="image">
                    <img src="img/pack11.jpg" alt="">
                </div>
                <div class="content">
                    <h3>Taj Mahal, Agra</h3>
                    <p>5500.00 ₹/person</p>
                    <a href="book.php" class="btn">Book Now</a>
                </div>
            </div>
            <div class="box">
                <div class="image">
                    <img src="img/pack12.jpg" alt="">
                </div>
                <div class="content">
                    <h3>Auli, Uttarakhand</h3>
                    <p>8500.00 ₹/person</p>
                    <p> </p>
                    <a href="book.php" class="btn">Book Now</a>
                </div>
            </div>
            <div class="box">
                <div class="image">
                    <img src="img/pack13.jpg" alt="">
                </div>
                <div class="content">
                    <h3>Lakshadweep</h3>
                    <p>15000.00 ₹/person</p>
                    <a href="book.php" class="btn">Book Now</a>
                </div>
            </div>
            <div class="box">
                <div class="image">
                    <img src="img/pack14.jpg" alt="">
                </div>
                <div class="content">
                    <h3>Jaipur, Rajasthan</h3>
                    <p>10000.00 ₹/person</p>
                    <a href="book.php" class="btn">Book Now</a>
                </div>
            </div>
            <div class="box">
                <div class="image">
                    <img src="img/pack15.jpg" alt="">
                </div>
                <div class="content">
                    <h3>Mukteshwar, UK</h3>
                    <p>12000.00 ₹/person </p>
                    <a href="book.php" class="btn">Book Now</a>
                </div>
            </div>
        </div>
    </section>



    <!-- Footer -->
    <?php include 'include/footer.php'; ?>


    <!-- swiper js link -->
    <script src="https://cdn.jsdelivr.net/npm/swiper@8/swiper-bundle.min.js"></script>

    <!-- javascript file -->
    <script src='script.js'></script>


</body>

</html>