<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Travelo</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
    <!-- font awesome CDN link -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">

    <!-- css file  -->
    <link rel="stylesheet" href="css/style.css">
    <!-- swiper css -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@8/swiper-bundle.min.css" />

</head>

<body>

    <!-- navbar -->
    <?php include 'include/nav.php'; ?>



    <!-- home section -->

    <section class="home">
        <div class="swiper home-slider">
            <div class="swiper-wrapper ">
                <div class="swiper-slide slide" style="background: url('img/home1.jpg') no-repeat">
                    <div class="content">
                        <span>Happy Journey</span>
                        <h3>Travel is my therapy.</h3>
                        <a href="package.php" class="btn">Discover more</a>
                    </div>

                </div>
                <div class="swiper-slide slide" style="background: url('img/home2.jpg') no-repeat">
                    <div class="content">
                        <span>"Your time is limited, so don't waste it living someone else's life. Don't be trapped by
                            dogma – which is living with the results of other people's thinking."-Steve Jobs</span>
                        <!-- <h3>Travel now</h3> -->
                        <a href="package.php" class="btn">Discover more</a>
                    </div>

                </div>
                <div class="swiper-slide slide" style="background: url('img/home3.jpg') no-repeat">
                    <div class="content">
                        <!-- <span>hello</span> -->
                        <h3>“Dare to live the life you’ve always wanted.”
                        </h3>
                        <a href="package.php" class="btn">Discover more</a>
                    </div>

                </div>
            </div>
            <div class="swiper-button-next"></div>
            <div class="swiper-button-prev"></div>
        </div>
    </section>


    <!-- About -->
    <section class="about">
        <div class="img">
            <p class="imglogo"><i class="fa-sharp fa-solid fa-plane"></i>Travelo</p>
        </div>

        <div class="aboutus">
            <h3>About us</h3>
            <p>Travelo commenced its operations in November, 2022 by focusing on the B2B2C (business to business to
                customer) distribution channel and providing travel agents access to its website to book domestic travel
                airline tickets in order to cater to the offline travel market in India.</p>
            <a href="about.php" class="btn">Know more</a>
        </div>
    </section>

    <!-- package -->
    <section class="home-packages">
        <h1 class="heading-title">
            Our Packages
        </h1>
        <div class="box-container">
            <div class="box">
                <div class="image">
                    <img src="img/pack.jpg" alt="">
                </div>
                <div class="content">
                    <h3>Andaman & Nicobar </h3>
                    <p>12000.00 ₹/person </p>
                    <a href="" class="btn">Book Now</a>
                </div>
            </div>
            <div class="box">
                <div class="image">
                    <img src="img/pack2.jpg" alt="">
                </div>
                <div class="content">
                    <h3>Manali, H.P</h3>
                    <p> 6000.00 ₹/person</p>
                    <a href="" class="btn">Book Now</a>
                </div>
            </div>
            <div class="box">
                <div class="image">
                    <img src="img/pack3.jpg" alt="">
                </div>
                <div class="content">
                    <h3>Alleppey, kerala</h3>
                    <p>7500.00 ₹/person</p>
                    <a href="" class="btn">Book Now</a>
                </div>
            </div>
        </div>
        <div class="load-more"> <a href="package.php" class="btn">More</a> </div>
    </section>


    <!-- home-offer -->
    <section class="home-offer">
        <div class="content">
            <h3>flat 50% off</h3>
            <p>Hurry up! This oppourunity is available for sometime.</p>
            <a href="book.php" class="btn">Grab Now</a>
        </div>
    </section>


    <!-- services -->

    <section class="services">

        <h1 class="heading-title">Our Services</h1>
        <div class="box-container">
            <div class="box">
                <img src="img/icon-1.png" alt="">
                <h3>Adventure</h3>
            </div>
            <div class="box">
                <img src="img/icon-2.png" alt="">
                <h3>Tour guide</h3>
            </div>
            <div class="box">
                <img src="img/icon-3.png" alt="">
                <h3>Trekking</h3>
            </div>
            <div class="box">
                <img src="img/icon-4.png" alt="">
                <h3>Camp fire</h3>
            </div>
            <div class="box">
                <img src="img/icon-5.png" alt="">
                <h3>Off road</h3>
            </div>
            <div class="box">
                <img src="img/icon-6.png" alt="">
                <h3>Campimg</h3>
            </div>
        </div>
    </section>


    <!-- Footer -->
    <?php include 'include/footer.php'; ?>


    <!-- swiper js link -->
    <script src="https://cdn.jsdelivr.net/npm/swiper@8/swiper-bundle.min.js"></script>

    <!-- javascript file -->
    <script src='script.js'></script>



</body>

</html>