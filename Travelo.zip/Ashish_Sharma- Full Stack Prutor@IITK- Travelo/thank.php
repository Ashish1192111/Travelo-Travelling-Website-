<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Travelo</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
    <!-- font awesome CDN link -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">

    <!-- css file  -->
    <link rel="stylesheet" href="css/style.css">
    <!-- swiper css -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@8/swiper-bundle.min.css" />

</head>

<body>

    <!-- navbar -->
    <?php include 'include/nav.php'; ?>
 

    <!-- thank -->
    <div class="thank">
        <div class="thankframe">
            <h1>Thanks for visiting here.......</h1>
            <h2>Your information is saved on our server.</h2>
            <h3>Our team call back to you later</h3>
            <a href="home.php" class="btn">Back to home</a>  
        </div>
    </div>
</body>
</html>