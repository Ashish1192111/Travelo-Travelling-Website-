<!-- footer -->

<section class="footer">
        <div class="box-container">

            <div class="box">
                <h3>Quick links</h3>
                <a href="home.php"> <i class="fas fa-angle-right"></i> Home</a>
                <a href="package.php"><i class="fas fa-angle-right"></i>Package</a>
                <a href="about.php"><i class="fas fa-angle-right"></i>About us</a>
                <a href="book.php"><i class="fas fa-angle-right"></i>Book now</a>

            </div>

            <div class="box">
                <h3>Extra links</h3>
                <a href="#"> <i class="fas fa-angle-right"></i>Ask question</a>
                <a href="about.php"> <i class="fas fa-angle-right"></i>About us</a>
                <a href="#"> <i class="fas fa-angle-right"></i>privacy policy</a>
                <a href="#"> <i class="fas fa-angle-right"></i>Terms and Condition</a>
            </div>

            <div class="box">
                <h3>Contact us</h3>
                <a href="#"> <i class="fas fa-phone"></i>+91-7071122145</a>
                <a href="#"> <i class="fas fa-phone"></i>+91-7270932188</a>
                <a href="#"> <i class="fas fa-envelope"></i>travelo@gmail.com</a>
                <a href="#"> <i class="fas fa-map"></i>Kanpur nagar, UP-208016</a>


            </div>

            <div class="box">
                <h3>Follow us</h3>
                <a href="#"> <i class="fab fa-facebook"></i>facebook</a>
                <a href="#"> <i class="fab fa-instagram"></i>Instagram</a>
                <a href="#"> <i class="fab fa-twitter"></i>Twitter</a>
                <a href="#"> <i class="fab fa-linkedin"></i>linkedin</a>


            </div>
        </div>

        <div class="box2">
            copyright &copy 2021-2022;&nbsp; <a href="home.php">www.travelo.com</a>| All right reserved!
        </div>

    </section>