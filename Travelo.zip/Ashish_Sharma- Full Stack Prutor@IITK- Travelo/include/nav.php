<section class="header">
        <a href="home.php" class="logo"><i class="fa-sharp fa-solid fa-plane"></i>Travelo</a>

        <nav class="navbar">
            <a href="home.php">HOME</a>
            <a href="package.php">PACKAGE</a>
            <a href="about.php">ABOUT US</a>
            <a href="book.php">BOOK NOW</a>
            
        </nav>

        <div id="menubars" class="fas fa-bars"></div>
    </section>