<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Travelo</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
    <!-- font awesome CDN link -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">

    <!-- css file  -->
    <link rel="stylesheet" href="css/style.css">
    <!-- swiper css -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@8/swiper-bundle.min.css" />

</head>

<body>

    <!-- navbar -->
    <?php include 'include/nav.php'; ?>

    <!-- Book now -->
    <div class="heading-book">
        <h3>Book Your Ticket</h3>
    </div>

    <section class="booking">
        <h1 class="heading-title">Fill this Form</h1>

        <form action="form.php" method="POST" class="form">

            <div class="fill-form">
                <div class="input">
                    <label for="fname">First name:</label>
                    <input type="text" placeholder="Enter your first name" name="fname" id="fname" required>
                </div>
                <div class="input">
                    <label for="lname">Last name:</label>
                    <input type="text" placeholder="Enter your last name" name="lname" id="lname" >
                </div>
                <div class="input">
                    <label for="email">Email-id:</label>
                    <input type="text" placeholder="Enter your mail" name="email" id="email" required>
                </div>
                <div class="input">
                    <label for="number">Mobile no:</label>
                    <input type="number" placeholder="Enter your number" name="number" id="number" required>
                </div>
                <div class="input">
                    <label for="address">Address:</label>
                    <input type="text" placeholder="Enter your address" name="address" id="address">
                </div>
                <div class="input">
                    <label for="trip">Trip place:</label>
                    <input type="text" placeholder="Enter your trip place" name="trip" id="trip" required>
                </div>
                <div class="input">
                    <label for="person">Number of persons:</label>
                    <input type="number" placeholder="how many person" name="person" id="person" required>
                </div>
                <div class="input">
                    <label for="arrival">Arrival time:</label>
                    <input type="date" name="arrival" id="arrival" required>
                </div>
                <div class="input">
                    <label for="departure">Departure time:</label>
                    <input type="date" name="departure" id="departure" required>
                </div>
                
                
            </div>
            <input type="submit" value="submit" name="send" class="btn">

        </form>
    </section>

    <!-- Footer -->
    <?php include 'include/footer.php'; ?>


    <!-- swiper js link -->
    <script src="https://cdn.jsdelivr.net/npm/swiper@8/swiper-bundle.min.js"></script>

    <!-- javascript file -->
    <script src='script.js'></script>

</body>

</html>